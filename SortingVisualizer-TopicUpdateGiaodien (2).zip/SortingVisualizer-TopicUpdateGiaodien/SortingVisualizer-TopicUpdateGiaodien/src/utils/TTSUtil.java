package utils;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TTSUtil {
    private static final String VOICE_NAME = "kevin16";
    private static Voice voice;

    static {
        VoiceManager voiceManager = VoiceManager.getInstance();
        voice = voiceManager.getVoice(VOICE_NAME);
        if (voice != null) {
            voice.allocate();
        } else {
            throw new IllegalStateException("Cannot find voice: " + VOICE_NAME);
        }
    }

    public static void speak(String text) {
        if (voice != null) {
            voice.speak(text);
        }
    }
}
