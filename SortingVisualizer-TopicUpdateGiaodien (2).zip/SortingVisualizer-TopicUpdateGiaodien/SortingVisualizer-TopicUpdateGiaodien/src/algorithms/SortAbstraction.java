package algorithms;

import views.Visualizer;

public abstract class SortAbstraction {
    public abstract void sort(Visualizer visualizer);
}